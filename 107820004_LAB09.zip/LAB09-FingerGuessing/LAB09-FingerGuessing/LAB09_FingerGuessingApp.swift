//
//  LAB09_FingerGuessingApp.swift
//  LAB09-FingerGuessing
//
//  Created by 上官 on 2021/5/18.
//

import SwiftUI

@main
struct LAB09_FingerGuessingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
