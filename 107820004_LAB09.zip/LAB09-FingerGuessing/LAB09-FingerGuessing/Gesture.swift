//
//  Gesture.swift
//  LAB09-FingerGuessing
//
//  Created by 上官 on 2021/5/18.
//

import Foundation

struct Gesture {
    let gesture: Ges
    
    enum Ges: String, CaseIterable {
        case stone = "石頭"
        case paper = "布"
        case scissors = "剪刀"
    }
}
