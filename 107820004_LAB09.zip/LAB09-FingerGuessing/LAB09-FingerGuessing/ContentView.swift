//
//  ContentView.swift
//  LAB09-FingerGuessing
//
//  Created by 上官 on 2021/5/18.
//

import SwiftUI

struct ContentView: View {
    @StateObject var model = Model()
    @State var string = "請按'出拳'開始猜拳"
    
    var body: some View {
        VStack(spacing: 70){
            Text("猜拳遊戲")
                .font(.largeTitle)
            
            HStack(spacing: 50){
                Text("玩家：")
                    .padding()
                Image((model.playerGesture?.gesture.rawValue)!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .padding()
                Text(model.playerGesture?.gesture.rawValue ?? "?")
                    .padding()
            }
            
            HStack(spacing: 50){
                Text("電腦：")
                    .padding()
                Image((model.computerGesture?.gesture.rawValue)!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .padding()
                Text(model.computerGesture?.gesture.rawValue ?? "?")
                    .padding()
            }
            
            Button(action: {
                model.play()
                if let result = model.result{
                    if result == .win {
                        string = "玩家獲勝！"
                    }else if result == .lose {
                        string = "電腦獲勝！"
                    }else {
                        string = "平手！"
                    }
                }
            }, label: {
                Text("出拳！")
                    .font(.title)
            })
            
            HStack{
                Text("結果：")
                    .font(.title)
                
                Text(string)
                    .foregroundColor(.red)
                    .font(.title)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
