//
//  GameResult.swift
//  LAB09-FingerGuessing
//
//  Created by 上官 on 2021/5/18.
//

import Foundation

enum GameResult {
    case win
    case lose
    case peace
}
