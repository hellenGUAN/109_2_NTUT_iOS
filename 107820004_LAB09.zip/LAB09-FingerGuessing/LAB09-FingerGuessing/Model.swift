//
//  Model.swift
//  LAB09-FingerGuessing
//
//  Created by 上官 on 2021/5/18.
//

import Foundation

class Model: ObservableObject {
    @Published var playerGesture: Gesture?
    @Published var computerGesture: Gesture?
    @Published var result: GameResult?
    
    var gestures1: [Gesture] = {
        var gestures = [Gesture]()
        for ges in Gesture.Ges.allCases{
            let gesture = Gesture(gesture: ges)
            gestures.append(gesture)
        }
        return gestures
    }()
    
    var gestures2: [Gesture] = {
        var gestures = [Gesture]()
        for ges in Gesture.Ges.allCases{
            let gesture = Gesture(gesture: ges)
            gestures.append(gesture)
        }
        return gestures
    }()
    
    init() {
        playerGesture = gestures1[0]
        computerGesture = gestures2[0]
    }
    
    func play() {
        gestures1.shuffle()
        gestures2.shuffle()
        playerGesture = gestures1[0]
        computerGesture = gestures2[0]
        result = checkResult()
    }
    
    func checkResult() -> GameResult {
        let player = playerGesture!.gesture.rawValue
        let computer = computerGesture!.gesture.rawValue
        if computer == "剪刀" {
            if player == "剪刀" {
                return .peace
            }else if player == "石頭" {
                return .win
            }else {
                return .lose
            }
        }else if computer == "石頭" {
            if player == "剪刀" {
                return .lose
            }else if player == "石頭" {
                return .peace
            }else {
                return .win
            }
        }else {
            if player == "剪刀" {
                return .win
            }else if player == "石頭" {
                return .lose
            }else {
                return .peace
            }
        }
    }
}
