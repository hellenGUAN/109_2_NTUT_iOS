//
//  Calculate.swift
//  LAB01-Calculator
//
//  Created by 上官 on 2021/4/29.
//

import Foundation

struct Calculate{
    
    var numberArray : Array<String> = []
    var result = ""
    
    func posNeg(at array: Array<String>) -> String{
        if (array.count > 1){
            var c = array
            c.removeFirst()
            c.removeFirst()
            return c.joined()
        }else {
            var c = Array(array[0])
            c.removeFirst()
            c.removeFirst()
            if(c[0] != "-"){
                c.insert("-", at: 0)
            }else {
                c.removeFirst()
            }
            return String(c)
        }
    }
    
    func percentage(at array: Array<String>) -> Array<String>{
        var c = array
        for index in 0...c.count-1{
            if (c[index] == "%"){
                c[index - 1] = String(Float(c[index-1])!/100)
                c.remove(at: index)
            }
            if(c[index] == c.last){
                break
            }
        }
        return c
    }
    
    func digitsCount(at string: String) ->  Int{
        let array = Array(string)
        var count:Int = 0
        for i in array{
            if i != "."{
                count += 1
            }else{
                break
            }
        }
        return count
    }
    
    func plusMinus(at array: Array<String>) -> Array<String>{
        var bool = 0
        var c:Array<String> = array
        while bool != 1{
            bool = 1
            for index in 0...c.count-1{
                if(c[index] == "+"){
                    bool = 0
                    let num1:Float? = Float(c[index-1])
                    let num2:Float? = Float(c[index+1])
                    let num3 = num1! + num2!
                    c.insert(String(num3), at: index-1)
                    for _ in 1...3{
                        c.remove(at: index)
                    }
                    break
                }
                
                if(c[index] == "-"){
                    bool = 0
                    let num1:Float? = Float(c[index-1])
                    let num2:Float? = Float(c[index+1])
                    let num3 = num1! - num2!
                    c.insert(String(num3), at: index-1)
                    for _ in 1...3{
                        c.remove(at: index)
                    }
                    break
                }
            }
        }
        return c
    }
    
    func multiplyDivide(at array: Array<String>) -> Array<String>{
        var bool = 0
        var c:Array<String> = array
        while bool != 1{
            bool = 1
            for index in 0...c.count-1{
                if(c[index] == "×"){
                    bool = 0
                    let num1:Double? = Double(c[index-1])
                    let num2:Double? = Double(c[index+1])
                    let num3 = num1! * num2!
                    let int = digitsCount(at: String(num3))
                    String(num3).count > 9
                        ? c.insert(String(format: "%.\(9-int)f",num3), at: index-1)
                        : c.insert(String(num3), at: index-1)
                    for _ in 1...3{
                        c.remove(at: index)
                    }
                    break
                }
                if(c[index] == "÷"){
                    bool = 0
                    var num3 = 0.0
                    let num1:Double? = Double(c[index-1])
                    let num2:Double? = Double(c[index+1])
                    if(num2 != 0){
                        num3 = Double(num1! / num2!)
                    }
                    String(num3).count > 9
                        ? c.insert(String(format: "%.8f",num3), at: index-1)
                        : c.insert(String(num3), at: index-1)
                    for _ in 1...3{
                        c.remove(at: index)
                    }
                    break
                }
            }
        }
        return c
    }
    
    func solveSurplusZeros(at string: String) -> String{
        var array = Array(string)
        let arraySlice = array.suffix(2)
        let newArray = Array(arraySlice)
        
        if(newArray[0] == "." && newArray[1] == "0"){
            array.removeLast()
            array.removeLast()
        }
        return String(array)
    }
    
    mutating func calculate(at array: Array<String>) -> String{
        numberArray = array
        if (numberArray[0].prefix(1) == "±"){
            result = posNeg(at: numberArray)
            return result
        }else {
            numberArray = percentage(at: numberArray)
            numberArray = multiplyDivide(at: numberArray)
            numberArray = plusMinus(at: numberArray)
            result = solveSurplusZeros(at: numberArray[0])
            return result
        }
    }
}
