//
//  ViewController.swift
//  LAB01-Calculator
//
//  Created by 上官 on 2021/3/8.
//

import UIKit

class ViewController: UIViewController {
    
    var numberArray = [""]
    var currentIndex:String.Index?
    
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var function: UILabel!
    
    @IBOutlet var digit: [UIButton]!
    
    @IBOutlet var operators: [UIButton]!
    
    @IBAction func digit(_ sender: UIButton) {
        if (function.text == "" && sender.currentTitle == "0"){
        }else if (function.text != ""){
            var s = function.text!
            print(s.last!)
            if (s.last!.isNumber || s.last! == "." || s.last! == "("){
                if (result.text != "0"){
                    result.text! += sender.currentTitle!
                }else {
                    result.text! = sender.currentTitle!
                }
                function.text! += sender.currentTitle!
            }else{
                result.text = sender.currentTitle!
                function.text! += sender.currentTitle!
                s = function.text!
                currentIndex = s.index(before: s.endIndex)
            }
        }else {
            result.text = sender.currentTitle!
            function.text = sender.currentTitle!
        }
    }
    
    @IBAction func dot(_ sender: Any) {
        let s = function.text!
        if (s.last!.isNumber){
            result.text! += "."
            function.text! += "."
        }
    }
    
    func putIntoArray(){
        let s = function.text!
        let range = currentIndex!..<s.endIndex
        numberArray.append(String(s[range]))
    }
    
    func solveTwoOps(at op: String){
        let s = function.text!
        var array = Array(s)
        array.removeLast()
        array.append(contentsOf: op)
        numberArray.removeLast()
        numberArray.removeLast()
        numberArray.append(op)
        function.text = String(array)
    }
    
    @IBAction func operators(_ sender: UIButton) {
        if (function.text == ""){
            function.text = "0"
        }
        let s = function.text!
        putIntoArray()
        if (sender.currentTitle == "-"){
            if (s.last!.isNumber || s.last! == "(" || s.last! == "%"){
//                result.text! += sender.currentTitle!
                function.text! += sender.currentTitle!
                numberArray.append(sender.currentTitle!)
            }else {
                solveTwoOps(at: sender.currentTitle!)
            }
        }else{
            if (s.last!.isNumber || s.last! == "%"){
                function.text! += sender.currentTitle!
                numberArray.append(sender.currentTitle!)
            }else {
                solveTwoOps(at: sender.currentTitle!)
            }
        }
    }
    
    @IBAction func posNeg(_ sender: UIButton) {
        if(function.text == ""){
            function.text = "±("
        }
    }
    
    @IBAction func percentage(_ sender: Any) {
        let s = function.text!
        putIntoArray()
        if (s.last!.isNumber){
            function.text! += "%"
            numberArray.append("%")
        }
    }
    
    @IBAction func equals(_ sender: Any) {
//        var array = [String]();
//        let a = function.text!;
//        var startindex = a.startIndex;
//        var sum = 0;
//        for i in 0...(a.count - 1){
//            let endindex = a.index(a.startIndex, offsetBy: i);
//            if a[endindex].isNumber == false{
//                let range = startindex..<endindex;
//                let c = a[range];
//                array.append(String(c));
//                array.append(String(a[endindex]));
//                startindex = a.index(after: endindex);
//            }else if (i == a.count-1){
//                array.append(String(a[startindex..<a.endIndex]));
//            }
//        }
//
//
//        var check = 0;
//        while check == 0{
//            check = 1;
//            for k in 0...(array.count - 1){
//                if array[k] == "x" || array[k] == "/"{
//                    check = 0;
//                    if array[k] == "x"{
//                        sum = Int(array[k-1])! * Int(array[k+1])!;
//                        print(sum);
//                        array[k-1] = String(sum);
//                        array.remove(at: k+1);
//                        array.remove(at: k);
//                        break;
//                    }else{
//                        sum = Int(array[k-1])! / Int(array[k+1])!;
//                        print(sum);
//                        array[k-1] = String(sum);
//                        array.remove(at: k+1);
//                        array.remove(at: k);
//                        break;
//                    }
//                }
//            }
//        }
//
//        var check1 = 0;
//
//        while check1 == 0{
//            check1 = 1;
//            for k in 0...(array.count - 1){
//                if array[k] == "+" || array[k] == "-"{
//                    check1 = 0;
//                    if array[k] == "+"{
//                        sum = Int(array[k-1])! + Int(array[k+1])!;
//                        print(sum);
//                        array[k-1] = String(sum);
//                        array.remove(at: k+1);
//                        array.remove(at: k);
//                        break;
//                    }else{
//                        sum = Int(array[k-1])! - Int(array[k+1])!;
//                        print(sum);
//                        array[k-1] = String(sum);
//                        array.remove(at: k+1);
//                        array.remove(at: k);
//                        break;
//                    }
//                }
//            }
//        }
//
//        result.text = array[0];
//        function.text = "";
//        s = "0";
//        op = "";
        
        let s = function.text!
        var index = s.index(s.startIndex, offsetBy: 1)
        putIntoArray()
        var c = Calculate()
        let answer = c.calculate(at: numberArray)
        let i1 = s.index(s.startIndex, offsetBy: s.count - 2)
        let i2 = s.index(s.startIndex, offsetBy: s.count - 3)
        if (s.last == "0"){
            if (s[i1] == "0" && s[i2] != "0"){
                function.text!.removeLast()
                function.text!.removeLast()
            }
        }
        if(s[index] == "("){
            function.text! += ")="
        }else {
            function.text! += "="
        }
        result.text = answer
    }
    
    @IBAction func AC(_ sender: Any) {
        result.text = "0"
        function.text = ""
        numberArray = []
        currentIndex = function.text!.startIndex
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        result.text = "0"
        numberArray = []
        currentIndex = String(function.text!).startIndex
        // Do any additional setup after loading the view.
    }


}

